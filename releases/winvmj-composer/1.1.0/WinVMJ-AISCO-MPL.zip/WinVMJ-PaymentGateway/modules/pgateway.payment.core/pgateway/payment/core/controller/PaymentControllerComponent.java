package pgateway.payment.core;

public abstract class PaymentControllerComponent implements PaymentController {
	
	protected String createInquiry(String amount, String desc) {
		return "[INQUIRY] Paid " + amount + " for " + desc;
	}
}