package pgateway.payment.core;

import java.util.HashMap;
import java.util.List;
import vmj.routing.route.VMJExchange;

public interface PaymentController {
	HashMap<String, Object> pay(VMJExchange paramVMJExchange);
}