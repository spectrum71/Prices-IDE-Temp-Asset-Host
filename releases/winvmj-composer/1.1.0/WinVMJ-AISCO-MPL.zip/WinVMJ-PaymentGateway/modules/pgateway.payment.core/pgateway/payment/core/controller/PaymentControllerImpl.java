package pgateway.payment.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

public class PaymentControllerImpl extends PaymentControllerComponent {
	@Route(url = "call/pgateway/pay")
	public HashMap<String, Object> pay(VMJExchange paramVMJExchange) {
		Object amount = paramVMJExchange.getPOSTBodyForm("amount");
		Object desc = paramVMJExchange.getPOSTBodyForm("description");
		
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("status", "succeed");
		hashMap.put("inquiry", createInquiry(amount.toString(), desc.toString()));
		
		return hashMap;
	}
}