module pgateway.payment.core {
    exports pgateway.payment.core;
    exports pgateway.payment;
	
    requires java.logging;
    requires vmj.routing.route;
}