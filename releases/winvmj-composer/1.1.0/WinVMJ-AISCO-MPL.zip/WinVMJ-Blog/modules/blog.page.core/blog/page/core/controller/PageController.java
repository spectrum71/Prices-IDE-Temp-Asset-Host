package blog.page.core;

import java.util.HashMap;
import java.util.List;
import vmj.routing.route.VMJExchange;

public interface PageController {
	HashMap<String, Object> createPost(VMJExchange paramVMJExchange);
}