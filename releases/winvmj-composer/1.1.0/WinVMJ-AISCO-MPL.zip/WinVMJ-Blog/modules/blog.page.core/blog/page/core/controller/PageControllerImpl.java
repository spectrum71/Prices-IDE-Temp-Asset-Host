package blog.page.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

public class PageControllerImpl extends PageControllerComponent {
	@Route(url = "call/page/create-post")
	public HashMap<String, Object> createPost(VMJExchange paramVMJExchange) {
		Object title = paramVMJExchange.getPOSTBodyForm("title");
		Object content = paramVMJExchange.getPOSTBodyForm("content");
		
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("status", "succeed");
		hashMap.put("post", createPost(title.toString(), content.toString()));
		
		return hashMap;
	}
}