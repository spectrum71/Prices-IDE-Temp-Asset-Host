package blog.page.core;

public abstract class PageControllerComponent implements PageController {
	
	protected String createPost(String title, String content) {
		return "[" + title + "]: " + content;
	}
}