module blog.page.core {
    exports blog.page.core;
    exports blog.page;
	
    requires java.logging;
    requires vmj.routing.route;
}