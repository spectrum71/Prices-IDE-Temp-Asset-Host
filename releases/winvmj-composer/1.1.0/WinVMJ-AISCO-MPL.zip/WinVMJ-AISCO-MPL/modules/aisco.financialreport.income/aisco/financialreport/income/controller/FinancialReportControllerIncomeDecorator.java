package aisco.financialreport.income;
import java.util.*;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import aisco.financialreport.core.FinancialReportControllerDecorator;
import aisco.financialreport.core.FinancialReportControllerComponent;
import aisco.financialreport.core.FinancialReport;
import aisco.financialreport.core.FinancialReportDecorator;
import aisco.financialreport.FinancialReportFactory;

import prices.auth.vmj.annotations.Restricted;

public class FinancialReportControllerIncomeDecorator extends FinancialReportControllerDecorator {

    public FinancialReportControllerIncomeDecorator(FinancialReportControllerComponent record) {
        super(record);
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/income/save")
    public List<HashMap<String,Object>> saveFinancialReport(VMJExchange vmjExchange) {
        FinancialReport financialReport = createFinancialReport(vmjExchange);
        financialReportDao.saveFinancialReport(financialReport);
        System.out.println(financialReport);
        return getAllFinancialReport(vmjExchange);
    }

    public FinancialReport createFinancialReport(VMJExchange vmjExchange) {
        String paymentMethod = vmjExchange.getGETParam("paymentMethod");
        FinancialReport financialReport = record.createFinancialReport(vmjExchange);
        FinancialReport financialReportIncome = FinancialReportFactory.createFinancialReport("aisco.financialreport.income.FinancialReportIncomeDecorator", financialReport, paymentMethod);

        return financialReportIncome;
    }

    // need to copy paste code from above because java doesn't have optional parameter
    // public FinancialReport createFinancialReport(VMJExchange vmjExchange, UUID id) {
    public FinancialReport createFinancialReport(VMJExchange vmjExchange, int id) {
        String paymentMethod = vmjExchange.getGETParam("paymentMethod");
        FinancialReport savedFinancialReport = financialReportDao.getFinancialReport(id);
        // UUID recordFinancialReportId = (((FinancialReportDecorator) savedFinancialReport).getRecord()).getId();
        int recordFinancialReportId = (((FinancialReportDecorator) savedFinancialReport).getRecord()).getId();
        FinancialReport financialReport = record.createFinancialReport(vmjExchange, recordFinancialReportId);
        FinancialReport financialReportIncome = FinancialReportFactory.createFinancialReport("aisco.financialreport.income.FinancialReportIncomeDecorator", id, financialReport, paymentMethod);

        return financialReportIncome;
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/income/update")
    public HashMap<String, Object> updateFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        FinancialReport financialReport = createFinancialReport(vmjExchange, id);
        financialReportDao.updateFinancialReport(financialReport);
        System.out.println(financialReport);
        return financialReport.toHashMap();
    }

    @Route(url="call/income/detail")
    public HashMap<String, Object> getFinancialReport(VMJExchange vmjExchange) {
        return record.getFinancialReport(vmjExchange);
    }

    @Route(url="call/income/list")
    public List<HashMap<String,Object>> getAllFinancialReport(VMJExchange vmjExchange) {
        List<FinancialReport> financialReportList = financialReportDao.getAllFinancialReport("FinancialReportIncomeDecorator");
        return transformFinancialReportListToHashMap(financialReportList);
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/income/delete")
    public List<HashMap<String,Object>> deleteFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        financialReportDao.deleteFinancialReport(id);
        return getAllFinancialReport(vmjExchange);
    }
}
