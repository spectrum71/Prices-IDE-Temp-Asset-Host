module aisco.donation.core {
    exports aisco.donation;
    exports aisco.donation.core;
    requires java.logging;
    requires prices.auth.vmj;
}
