package aisco.financialreport.frequency;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;

import aisco.financialreport.core.FinancialReportDecorator;
import aisco.financialreport.core.FinancialReportComponent;

@Entity
@Table(name="financialreport_frequency")
public class FinancialReportFrequencyDecorator extends FinancialReportDecorator {

    @Column
    public String frequency;

    public FinancialReportFrequencyDecorator(FinancialReportComponent record, String frequency) {
        super(record);
        this.frequency = frequency;
    }

    // public FinancialReportFrequencyDecorator(UUID id, FinancialReportComponent record, String frequency) {
    public FinancialReportFrequencyDecorator(int id, FinancialReportComponent record, String frequency) {
        super(id, record);
        this.frequency = frequency;
    }

    public FinancialReportFrequencyDecorator() {
        super();
    }

    public String getFrequency() {
        return this.frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            " frequency='" + getFrequency() + "'" +
            ", record='" + getRecord() + "'" +
            "}";
    }

    public HashMap<String, Object> toHashMap() {
        HashMap<String, Object> financialReportMap = record.toHashMap();
        financialReportMap.put("id", id);
        financialReportMap.put("frequency", getFrequency());
        return financialReportMap;
    }

    /**
     * modifies
     */
    /* delta modifies method */
    @Route(url = "printHeader-frequency")
    public HashMap<String, Object> printHeader(VMJExchange vmjExchange) {
        HashMap<String, Object> hasil = new HashMap<>();
        hasil.put("header", "Financial Report - Delta - Frequency");
        return hasil;
    }
}
