package aisco.program.core;

import java.util.*;

import vmj.routing.route.VMJExchange;
import vmj.hibernate.integrator.DaoUtil;

public abstract class ProgramControllerComponent implements ProgramController {
    protected DaoUtil<Program> programDao;

    public ProgramControllerComponent(){
        this.programDao = new DaoUtil<Program>(aisco.program.core.ProgramComponent.class);
    }

    public abstract List<HashMap<String,Object>> saveProgram(VMJExchange vmjExchange);
    public abstract Program createProgram(VMJExchange vmjExchange);
    public abstract HashMap<String, Object> updateProgram(VMJExchange vmjExchange);
    public abstract HashMap<String, Object> getProgram(VMJExchange vmjExchange);
    public abstract List<HashMap<String,Object>> getAllProgram(VMJExchange vmjExchange);
    public abstract List<HashMap<String,Object>> transformProgramListToHashMap(List<Program> programList);
    public abstract List<HashMap<String,Object>> deleteProgram(VMJExchange vmjExchange);
}
