package aisco.chartofaccount.core;

import java.util.*;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import aisco.chartofaccount.ChartOfAccountFactory;

import prices.auth.vmj.annotations.Restricted;

public class ChartOfAccountControllerImpl extends ChartOfAccountControllerComponent {

    @Restricted(permissionName="administrator")
    @Route(url="call/chart-of-account/save")
    public List<HashMap<String,Object>> saveChartOfAccount(VMJExchange vmjExchange) {
        ChartOfAccount chartOfAccount = createChartOfAccount(vmjExchange);
        chartOfAccountDao.saveObject(chartOfAccount);
        System.out.println(chartOfAccount);
        return getAllChartOfAccount(vmjExchange);
    }

    public ChartOfAccount createChartOfAccount(VMJExchange vmjExchange) {
        String codeStr = vmjExchange.getGETParam("code");
        int code = Integer.parseInt(codeStr);
        String name = vmjExchange.getGETParam("name");
        String description = vmjExchange.getGETParam("description");
        String reference = vmjExchange.getGETParam("reference");
        ChartOfAccount chartOfAccount = ChartOfAccountFactory.createChartOfAccount("aisco.chartofaccount.core.ChartOfAccountImpl", code, name, description, reference);
        return chartOfAccount;
    }

    // need to copy paste code from above because java doesn't have optional parameter
    // public ChartOfAccount createChartOfAccount(VMJExchange vmjExchange, UUID id) {
    public ChartOfAccount createChartOfAccount(VMJExchange vmjExchange, int id) {
        String codeStr = vmjExchange.getGETParam("code");
        int code = Integer.parseInt(codeStr);
        String name = vmjExchange.getGETParam("name");
        String description = vmjExchange.getGETParam("description");
        String reference = vmjExchange.getGETParam("reference");
        ChartOfAccount chartOfAccount = ChartOfAccountFactory.createChartOfAccount("aisco.chartofaccount.core.ChartOfAccountImpl", id, code, name, description, reference);
        return chartOfAccount;
    }

    @Restricted(permissionName="administrator")
    @Route(url="call/chart-of-account/update")
    public HashMap<String, Object> updateChartOfAccount(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        ChartOfAccount chartOfAccount = createChartOfAccount(vmjExchange, id);
        chartOfAccountDao.updateObject(chartOfAccount);
        return chartOfAccount.toHashMap();
    }

    @Route(url="call/chart-of-account/detail")
    public HashMap<String, Object> getChartOfAccount(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        ChartOfAccount chartOfAccount = chartOfAccountDao.getObject(id);
        System.out.println(chartOfAccount);
        return chartOfAccount.toHashMap();
    }

    @Route(url="call/chart-of-account/list")
    public List<HashMap<String,Object>> getAllChartOfAccount(VMJExchange vmjExchange) {
        List<ChartOfAccount> chartOfAccountList = chartOfAccountDao.getAllObject("ChartOfAccountImpl");
        return transformChartOfAccountListToHashMap(chartOfAccountList);
    }

    public List<HashMap<String,Object>> transformChartOfAccountListToHashMap(List<ChartOfAccount> chartOfAccountList) {
        List<HashMap<String,Object>> resultList = new ArrayList<HashMap<String,Object>>();
        for(int i = 0; i < chartOfAccountList.size(); i++) {
            resultList.add(chartOfAccountList.get(i).toHashMap());
        }

        return resultList;
    }

    @Restricted(permissionName="administrator")
    @Route(url="call/chart-of-account/delete")
    public List<HashMap<String,Object>> deleteChartOfAccount(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        chartOfAccountDao.deleteObject(id);
        return getAllChartOfAccount(vmjExchange);
    }
}
