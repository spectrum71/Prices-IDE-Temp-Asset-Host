package aisco.chartofaccount.core;

import java.util.*;

import vmj.routing.route.VMJExchange;
import vmj.hibernate.integrator.DaoUtil;

public abstract class ChartOfAccountControllerComponent implements ChartOfAccountController {
    protected DaoUtil<ChartOfAccount> chartOfAccountDao;

    public ChartOfAccountControllerComponent(){
        this.chartOfAccountDao = new DaoUtil<ChartOfAccount>(aisco.chartofaccount.core.ChartOfAccountComponent.class);
    }

    public abstract List<HashMap<String,Object>> saveChartOfAccount(VMJExchange vmjExchange);
    public abstract ChartOfAccount createChartOfAccount(VMJExchange vmjExchange);
    // public abstract ChartOfAccount createChartOfAccount(VMJExchange vmjExchange, UUID id);
    public abstract ChartOfAccount createChartOfAccount(VMJExchange vmjExchange, int id);
    public abstract HashMap<String, Object> updateChartOfAccount(VMJExchange vmjExchange);
    public abstract HashMap<String, Object> getChartOfAccount(VMJExchange vmjExchange);
    public abstract List<HashMap<String,Object>> getAllChartOfAccount(VMJExchange vmjExchange);
    public abstract List<HashMap<String,Object>> transformChartOfAccountListToHashMap(List<ChartOfAccount> chartOfAccountList);
    public abstract List<HashMap<String,Object>> deleteChartOfAccount(VMJExchange vmjExchange);
}
