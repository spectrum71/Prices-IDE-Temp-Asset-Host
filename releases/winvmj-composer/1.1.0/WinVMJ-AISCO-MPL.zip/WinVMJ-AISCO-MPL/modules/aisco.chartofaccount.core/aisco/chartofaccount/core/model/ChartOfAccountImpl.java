package aisco.chartofaccount.core;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="chartofaccount_impl")
public class ChartOfAccountImpl extends ChartOfAccountComponent {

    @Column
	public int code;

	@Column
    public String name;

	@Column
    public String description;

	@Column
    public String reference;

    public ChartOfAccountImpl(int code, String name, String description, String reference) {
        // this.id = UUID.randomUUID();
		Random r = new Random();
		this.id = r.nextInt();
		this.code = code;
        this.name = name;
        this.description = description;
        this.reference = reference;
    }

	public ChartOfAccountImpl() {
		// this.id = UUID.randomUUID();
		Random r = new Random();
		this.id = r.nextInt();
		this.code = 0;
        this.name = "";
        this.description = "";
        this.reference = "";
    }

    public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}
}