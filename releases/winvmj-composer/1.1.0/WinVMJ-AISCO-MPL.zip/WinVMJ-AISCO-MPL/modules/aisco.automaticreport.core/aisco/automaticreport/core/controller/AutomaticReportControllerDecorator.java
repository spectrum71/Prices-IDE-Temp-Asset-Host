package aisco.automaticreport.core;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

public abstract class AutomaticReportControllerDecorator extends AutomaticReportControllerComponent {
    protected AutomaticReportControllerComponent record;

    public AutomaticReportControllerDecorator(AutomaticReportControllerComponent record) {
        this.record = record;
    }

    @Route(url = "call/automatic-report/list-decorator")
    public List<HashMap<String,Object>> list(VMJExchange vmjExchange) {
        return record.list(vmjExchange);
    }
}