package aisco.financialreport.core;

import java.util.UUID;
import java.util.List;

public interface FinancialReportDao {
    void saveFinancialReport(FinancialReport financialReport);
    void updateFinancialReport(FinancialReport financialReport);
    // FinancialReport getFinancialReport(UUID id);
    FinancialReport getFinancialReport(int id);
    List<FinancialReport> getAllFinancialReport(String tableName);
    // void deleteFinancialReport(UUID id);
    void deleteFinancialReport(int id);
    // <T> T getProxyObject(Class<T> type, UUID idObject);
    <T> T getProxyObject(Class<T> type, int idObject);
}