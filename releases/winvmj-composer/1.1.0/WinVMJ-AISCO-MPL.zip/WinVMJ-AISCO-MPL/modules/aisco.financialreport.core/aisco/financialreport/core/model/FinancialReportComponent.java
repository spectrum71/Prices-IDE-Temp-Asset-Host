package aisco.financialreport.core;

import java.util.*;

import aisco.program.core.ProgramComponent;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import aisco.program.core.Program;

import aisco.chartofaccount.core.ChartOfAccount;

@Entity
@Table(name="financialreport_comp")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class FinancialReportComponent implements FinancialReport {

    // protected UUID id;
    @Id
    protected int id;

    // public UUID getId() {
    public int getId() {
        return this.id;
    }
    // public void setId(UUID id) {
    public void setId(int id) {
        this.id = id;
    }

    public abstract String getDatestamp();
    public abstract void setDatestamp(String datestamp);

    public abstract long getAmount();
    public abstract void setAmount(long amount);

    public abstract String getDescription();
    public abstract void setDescription(String description);

    // public abstract Program getProgram();
    // public abstract void setProgram(Program program);

    // public abstract ChartOfAccount getCoa();
    // public abstract void setCoa(ChartOfAccount coa);

    public abstract String getProgramName();
    public abstract void setProgramName(String programName);

    public abstract String getIdCoa();
    public abstract void setIdCoa(String idCoa);

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", datestamp='" + getDatestamp() + "'" +
            ", amount='" + getAmount() + "'" +
            ", description='" + getDescription() + "'" +
            // ", idProgram='" + ((getProgram() == null) ? "" : getProgram().getIdProgram()) + "'" +
            // ", idCoa='" + ((getCoa() == null) ? "" : getCoa().getId()) + "'" +
            ", programName='" + getProgramName() + "'" +
            ", idCoa='" + getIdCoa() + "'" +
            "}";
    }

    public HashMap<String, Object> toHashMap() {
        HashMap<String, Object> financialReportMap = new HashMap<String,Object>();
        financialReportMap.put("id", getId());
        financialReportMap.put("datestamp", getDatestamp());
        financialReportMap.put("amount", getAmount());
        financialReportMap.put("description", getDescription());
        // if (getProgram() != null) {
        //     financialReportMap.put("idProgram", getProgram().getIdProgram());
        // }
        // if (getCoa() != null) {
        //     financialReportMap.put("idCoa", getCoa().getId());
        // }
        financialReportMap.put("programName", getProgramName());
        financialReportMap.put("idCoa", getIdCoa());
        return financialReportMap;
    }

    @Route(url="getDescription")
    public String getDescription(VMJExchange vmjExchange) {
        // #TODO: Implement this
        // Object id = vmjExchange.getGETParam("id");
        // ArrayList<String> requiredFields = new ArrayList<>();
        // requiredFields.add("description");

        // HashMap<String, Object> hasil = vmjDBUtil.getDataById("financialreport_core", requiredFields, id.toString());

        // return hasil.get("description").toString();
        return "dummy response";
    }

    @Route(url="getAmount")
    public HashMap<String, Object> getAmount(VMJExchange vmjExchange) {
        // #TODO: Implement this
        // Object id = vmjExchange.getGETParam("id");
        // ArrayList<String> requiredFields = new ArrayList<>();
        // requiredFields.add("amount");

        // HashMap<String, Object> hasil = vmjDBUtil.getDataById("financialreport_core", requiredFields, id.toString());

        // return hasil;
        return null;
    }

    @Route(url="getProgram")
    public HashMap<String, Object> getProgram(VMJExchange vmjExchange) {
        // #TODO: Implement this
        // Object id = vmjExchange.getGETParam("id");
        // ArrayList<String> requiredFields = new ArrayList<>();
        // requiredFields.add("idProgram");

        // HashMap<String, Object> hasil = vmjDBUtil.getDataById("financialreport_core", requiredFields, id.toString());

        // return hasil;
        return null;
    }

    public abstract HashMap<String, Object> printHeader(VMJExchange vmjExchange);
}
