package aisco.financialreport.core;

import java.util.*;

import vmj.routing.route.VMJExchange;

public abstract class FinancialReportControllerComponent implements FinancialReportController {
    protected FinancialReportDao financialReportDao;

    public FinancialReportControllerComponent(){
        this.financialReportDao = new FinancialReportDaoImpl();
    }

    public abstract List<HashMap<String,Object>> saveFinancialReport(VMJExchange vmjExchange);
    public abstract FinancialReport createFinancialReport(VMJExchange vmjExchange);
    // public abstract FinancialReport createFinancialReport(VMJExchange vmjExchange, UUID id);
    public abstract FinancialReport createFinancialReport(VMJExchange vmjExchange, int id);
    public abstract HashMap<String, Object> updateFinancialReport(VMJExchange vmjExchange);
    public abstract HashMap<String, Object> getFinancialReport(VMJExchange vmjExchange);
    public abstract List<HashMap<String,Object>> getAllFinancialReport(VMJExchange vmjExchange);
    public abstract List<HashMap<String,Object>> transformFinancialReportListToHashMap(List<FinancialReport> financialReportList);
    public abstract List<HashMap<String,Object>> deleteFinancialReport(VMJExchange vmjExchange);
}
