package aisco.financialreport.core;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.OneToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.CascadeType;

import aisco.program.core.Program;
import aisco.chartofaccount.core.ChartOfAccount;

@MappedSuperclass
public abstract class FinancialReportDecorator extends FinancialReportComponent {

    @OneToOne(cascade=CascadeType.ALL)
    protected FinancialReportComponent record;

    public FinancialReportDecorator(FinancialReportComponent record) {
        this.record = record;
        // this.id = UUID.randomUUID();
        Random r = new Random();
		this.id = r.nextInt();
    }

    // public FinancialReportDecorator(UUID id, FinancialReportComponent record) {
    public FinancialReportDecorator(int id, FinancialReportComponent record) {
        this.id = id;
        this.record = record;
    }

    public FinancialReportDecorator() {
        super();
        this.record = new FinancialReportImpl();
        // this.id = UUID.randomUUID();
        Random r = new Random();
		this.id = r.nextInt();
    }

    public FinancialReportComponent getRecord() {
        return this.record;
    }

    public void setRecord(FinancialReportComponent record) {
        this.record = record;
    }

    public String getDatestamp() {
        return this.record.getDatestamp();
    }
    public void setDatestamp(String datestamp) {
        this.record.setDatestamp(datestamp);
    }

    public long getAmount() {
        return this.record.getAmount();
    }
    public void setAmount(long amount) {
        this.record.setAmount(amount);
    }

    public String getDescription() {
        return this.record.getDescription();
    }
    public void setDescription(String description) {
        this.record.setDescription(description);
    }

    // public Program getProgram() {
    //     return this.record.getProgram();
    // }
    // public void setProgram(Program program) {
    //     this.record.setProgram(program);
    // }

    // public ChartOfAccount getCoa() {
    //     return this.record.getCoa();
    // }
    // public void setCoa(ChartOfAccount coa) {
    //     this.record.setCoa(coa);
    // }

    public String getProgramName() {
        return this.record.getProgramName();
    }
    public void setProgramName(String programName) {
        this.record.setProgramName(programName);
    }

    public String getIdCoa() {
        return this.record.getIdCoa();
    }
    public void setIdCoa(String idCoa) {
        this.record.setIdCoa(idCoa);
    }

    public HashMap<String, Object> toHashMap() {
        return this.record.toHashMap();
    }

    @Route(url = "getAmount-decorator")
    public HashMap<String, Object> getAmount(VMJExchange vmjExchange) {
        return record.getAmount(vmjExchange);
    }

    @Route(url = "getDescription-decorator")
    public String getDescription(VMJExchange vmjExchange) {
        return record.getDescription(vmjExchange);
    }

    @Route(url="getProgram-decorator")
    public HashMap<String, Object> getProgram(VMJExchange vmjExchange) {
        return record.getProgram(vmjExchange);
    }

    @Route(url="printHeader")
    public HashMap<String, Object> printHeader(VMJExchange vmjExchange) {
        return record.printHeader(vmjExchange);
    }
}