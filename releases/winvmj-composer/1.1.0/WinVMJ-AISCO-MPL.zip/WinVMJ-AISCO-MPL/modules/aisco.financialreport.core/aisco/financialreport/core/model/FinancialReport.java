package aisco.financialreport.core;
import aisco.program.core.Program;
import aisco.chartofaccount.core.ChartOfAccount;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;
import java.util.*;

public interface FinancialReport {
    String getDescription(VMJExchange vmjExchange);
    HashMap<String,Object> getAmount(VMJExchange vmjExchange);
    HashMap<String,Object> getProgram(VMJExchange vmjExchange);
    HashMap<String,Object> printHeader(VMJExchange vmjExchange);

    // UUID getId();
    // void setId(UUID id);
    int getId();
    void setId(int id);

    String getDatestamp();
    void setDatestamp(String datestamp);

    long getAmount();
    void setAmount(long amount);

    String getDescription();
    void setDescription(String description);

    // Program getProgram();
    // void setProgram(Program program);

    // ChartOfAccount getCoa();
    // void setCoa(ChartOfAccount coa);

    String getProgramName();
    void setProgramName(String programName);

    String getIdCoa();
    void setIdCoa(String idCoa);

    HashMap<String, Object> toHashMap();
}