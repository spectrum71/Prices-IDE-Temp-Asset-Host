module aisco.automaticreport.threelevel {
    exports aisco.automaticreport.threelevel;
    requires java.logging;
    requires vmj.routing.route;
    requires vmj.object.mapper;

    requires aisco.automaticreport.core;
}