package aisco.donation.core;

public interface Donation {
    void getDonation();
    void addDonation();
}
