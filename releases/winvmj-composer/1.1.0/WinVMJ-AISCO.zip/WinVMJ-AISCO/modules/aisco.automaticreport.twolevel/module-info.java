module aisco.automaticreport.twolevel {
    exports aisco.automaticreport.twolevel;
    requires java.logging;
    requires vmj.routing.route;
    requires vmj.object.mapper;

    requires aisco.automaticreport.core;
}