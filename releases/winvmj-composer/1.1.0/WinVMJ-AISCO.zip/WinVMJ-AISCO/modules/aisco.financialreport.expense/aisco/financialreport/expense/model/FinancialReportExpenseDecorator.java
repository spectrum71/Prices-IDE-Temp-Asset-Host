package aisco.financialreport.expense;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Entity;
import javax.persistence.Table;

import aisco.financialreport.core.FinancialReportDecorator;
import aisco.financialreport.core.FinancialReportComponent;

@Entity
@Table(name="financialreport_expense")
public class FinancialReportExpenseDecorator extends FinancialReportDecorator {

    public FinancialReportExpenseDecorator(FinancialReportComponent record) {
        super(record);
    }

    // public FinancialReportExpenseDecorator(UUID id, FinancialReportComponent record) {
    public FinancialReportExpenseDecorator(int id, FinancialReportComponent record) {
        super(id, record);
    }

    public FinancialReportExpenseDecorator(){
        super();
    }

    public HashMap<String, Object> toHashMap() {
        HashMap<String, Object> financialReportMap = record.toHashMap();
        financialReportMap.put("id", id);
        return financialReportMap;
    }

    @Route(url = "printHeader-expense")
    public HashMap<String, Object> printHeader(VMJExchange vmjExchange) {
        HashMap<String, Object> hasil = new HashMap<>();
        hasil.put("header", "Financial Report - Delta - Expense");
        return hasil;
    }

    @Route(url = "sumExpense")
    public HashMap<String, Object> sumExpense(VMJExchange vmjExchange) {
        HashMap<String, Object> hasil = new HashMap<>();
        hasil.put("Total Expense", "masih hardcoded");
        return hasil;
    }

}
