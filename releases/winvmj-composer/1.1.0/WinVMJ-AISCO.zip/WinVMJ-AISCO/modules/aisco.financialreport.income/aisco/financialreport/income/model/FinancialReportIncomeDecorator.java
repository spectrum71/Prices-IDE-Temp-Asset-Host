package aisco.financialreport.income;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;

import aisco.financialreport.core.FinancialReportDecorator;
import aisco.financialreport.core.FinancialReportComponent;

@Entity
@Table(name="financialreport_income")
public class FinancialReportIncomeDecorator extends FinancialReportDecorator {

    @Column
    public String paymentMethod;

    public FinancialReportIncomeDecorator(FinancialReportComponent record, String paymentMethod) {
        super(record);
        this.paymentMethod = paymentMethod;
    }

    // public FinancialReportIncomeDecorator(UUID id, FinancialReportComponent record, String paymentMethod) {
    public FinancialReportIncomeDecorator(int id, FinancialReportComponent record, String paymentMethod) {
        super(id, record);
        this.paymentMethod = paymentMethod;
    }

    public FinancialReportIncomeDecorator(){
        super();
    }

    public String getPaymentMethod() {
        return this.paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            " paymentMethod='" + getPaymentMethod() + "'" +
            ", record='" + getRecord() + "'" +
            "}";
    }

    public HashMap<String, Object> toHashMap() {
        HashMap<String, Object> financialReportMap = record.toHashMap();
        financialReportMap.put("id", id);
        financialReportMap.put("paymentMethod", getPaymentMethod());
        return financialReportMap;
    }

    /**
     * modifies
     */
    /* delta modifies method */
    @Route(url = "printHeader-income")
    public HashMap<String, Object> printHeader(VMJExchange vmjExchange) {
        HashMap<String, Object> hasil = new HashMap<>();
        hasil.put("header", "Financial Report - Delta - Income");
        return hasil;
    }

    @Route(url = "sumIncome")
    public HashMap<String, Object> sumIncome(VMJExchange vmjExchange) {
        // TODO: Implement this
        // String sqlQuery = "select core.amount from financialreport_core as core, financialreport_income as reportIncome where core.id=reportIncome.record_id";

        // VMJDatabaseUtil dbUtil = new VMJDatabaseUtil();

        // int total = 0;

        // ArrayList<Object> incomes = dbUtil.queryForAColumn(sqlQuery, "amount");

        // for (Object income : incomes) {
        //     total += (int) income;
        // }
        HashMap<String, Object> hasil = new HashMap<>();
        hasil.put("Total Income", "masih hardcoded");
        return hasil;
    }
}
