module aisco.financialreport.income {
    requires aisco.financialreport.core;
    exports aisco.financialreport.income;
    requires vmj.object.mapper;
    requires vmj.routing.route;
    requires prices.auth.vmj;

    opens aisco.financialreport.income to gson;
}
