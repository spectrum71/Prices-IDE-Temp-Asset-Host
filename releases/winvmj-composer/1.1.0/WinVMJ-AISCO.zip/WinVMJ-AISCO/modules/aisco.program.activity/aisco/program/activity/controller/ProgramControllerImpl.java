package aisco.program.activity;

import java.util.*;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import aisco.program.ProgramFactory;
import aisco.program.core.ProgramControllerComponent;
import aisco.program.core.Program;

import prices.auth.vmj.annotations.Restricted;

public class ProgramControllerImpl extends ProgramControllerComponent {

    @Restricted(permissionName="ModifyProgramImpl")
    @Route(url="call/program/save")
    public List<HashMap<String,Object>> saveProgram(VMJExchange vmjExchange) {
        Program program = createProgram(vmjExchange);
        programDao.saveObject(program);
        System.out.println(program);
        return getAllProgram(vmjExchange);
    }

    public Program createProgram(VMJExchange vmjExchange) {
        String name = vmjExchange.getGETParam("name");
        String description = vmjExchange.getGETParam("description");
        String target = vmjExchange.getGETParam("target");
        String partner = vmjExchange.getGETParam("partner");
        String logoUrl = vmjExchange.getGETParam("logoUrl");
        String executionDate = vmjExchange.getGETParam("executionDate");
        Program program = ProgramFactory.createProgram("aisco.program.activity.ProgramImpl", name, description, target, partner, logoUrl, executionDate);
        return program;
    }

    @Restricted(permissionName="ModifyProgramImpl")
    @Route(url="call/program/update")
    public HashMap<String, Object> updateProgram(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        Program program = createProgram(vmjExchange);
        program.setIdProgram(id);
        programDao.updateObject(program);
        return program.toHashMap();
    }

    @Route(url="call/program/detail")
    public HashMap<String, Object> getProgram(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        Program program = programDao.getObject(id);
        System.out.println(program);
        try {
            return program.toHashMap();
        } catch (NullPointerException e) {
            HashMap<String, Object> blank = new HashMap<>();
            blank.put("error", "Missing GET Params");
            return blank;
        }
    }

    @Route(url="call/program/list")
    public List<HashMap<String,Object>> getAllProgram(VMJExchange vmjExchange) {
        List<Program> programList = programDao.getAllObject("ProgramImpl");
        return transformProgramListToHashMap(programList);
    }

    public List<HashMap<String,Object>> transformProgramListToHashMap(List<Program> programList) {
        List<HashMap<String,Object>> resultList = new ArrayList<HashMap<String,Object>>();
        for(int i = 0; i < programList.size(); i++) {
            resultList.add(programList.get(i).toHashMap());
        }

        return resultList;
    }

    @Restricted(permissionName="ModifyProgramImpl")
    @Route(url="call/program/delete")
    public List<HashMap<String,Object>> deleteProgram(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        programDao.deleteObject(id);
        return getAllProgram(vmjExchange);
    }
}
