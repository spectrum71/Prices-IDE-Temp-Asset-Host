package aisco.program.core;

import java.util.*;

public abstract class ProgramDecorator extends ProgramComponent{
    
    public ProgramComponent record;

    public ProgramDecorator(ProgramComponent record) {
        this.record = record;
        // this.idProgram = UUID.randomUUID();
        Random r = new Random();
		this.idProgram = r.nextInt();
    }

    public ProgramDecorator() {
        super();
        // this.idProgram = UUID.randomUUID();
        Random r = new Random();
		this.idProgram = r.nextInt();
    }

    public String getName() {
        return this.record.getName();
    }

    public void setName(String name) {
        this.record.setName(name);
    }

    public String getDescription() {
        return this.record.getDescription();
    }

    public void setDescription(String description) {
        this.record.setDescription(description);
    }

    public String getTarget() {
        return this.record.getTarget();
    }

    public void setTarget(String target) {
        this.record.setTarget(target);
    }

    public String getPartner() {
        return this.record.getPartner();
    }

    public void setPartner(String partner) {
        this.record.setPartner(partner);
    }

    public String getLogoUrl() {
        return this.record.getLogoUrl();
    }

    public void setLogoUrl(String logoUrl) {
        this.record.setLogoUrl(logoUrl);
    }

    public String getExecutionDate() {
        return this.record.getExecutionDate();
    }

    public void setExecutionDate(String executionDate) {
        this.record.setExecutionDate(executionDate);
    }

}