module aisco.financialreport.frequency {
    requires aisco.financialreport.core;
    exports aisco.financialreport.frequency;
    requires vmj.object.mapper;
    requires vmj.routing.route;
    requires prices.auth.vmj;

    opens aisco.financialreport.frequency to gson;
}
