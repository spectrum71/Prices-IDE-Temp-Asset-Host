package aisco.summary.core;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

public abstract class SummaryControllerDecorator extends SummaryControllerComponent {

    protected SummaryControllerComponent record;

    public SummaryControllerDecorator(SummaryControllerComponent record) {
        this.record = record;
    }

    @Route(url = "call/summary/list-decorator")
    public ArrayList<HashMap<String,Object>> list(VMJExchange vmjExchange) {
        return record.list(vmjExchange);
    }
}