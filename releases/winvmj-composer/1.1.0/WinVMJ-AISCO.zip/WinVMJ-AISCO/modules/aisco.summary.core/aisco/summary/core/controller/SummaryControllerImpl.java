package aisco.summary.core;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

public class SummaryControllerImpl extends SummaryControllerComponent {

    public SummaryControllerImpl() {}
}