package aisco.financialreport;
import aisco.financialreport.core.FinancialReportController;

import java.lang.reflect.Constructor;
import java.util.logging.Logger;



public class FinancialReportControllerFactory {
    private static final Logger LOGGER = Logger.getLogger(FinancialReportControllerFactory.class.getName());

    private FinancialReportControllerFactory()
    {

    }

    /** initiate features **/
    public static FinancialReportController createFinancialReportController(String fullyQualifiedName, Object... base)
    {   //FinancialReportController record = (base.length==0) ? null: (FinancialReportController) base[0];
        FinancialReportController record = null;
        // if (checkConfig(fullyQualifiedName,base[0]))
        if(true)
        {
            try {
                Class<?> clz = Class.forName(fullyQualifiedName);
                Constructor<?> constructor = clz.getDeclaredConstructors()[0];
                System.out.println(constructor.toString());
                record = (FinancialReportController) constructor.newInstance(base);
            } 
            catch (IllegalArgumentException e)
            {
                LOGGER.severe("Failed to create instance of Financial Report.");
                LOGGER.severe("Given FQN: " + fullyQualifiedName);
                LOGGER.severe("Failed to run: Check your constructor argument");
                System.out.println(e.getMessage());
                System.exit(20);
            }
            catch (ClassCastException e)
            {   LOGGER.severe("Failed to create instance of Financial Report.");
                LOGGER.severe("Given FQN: " + fullyQualifiedName);
                LOGGER.severe("Failed to cast the object");
                System.exit(30);
            }
            catch (ClassNotFoundException e)
            {
                LOGGER.severe("Failed to create instance of Financial Report.");
                LOGGER.severe("Given FQN: " + fullyQualifiedName);
                LOGGER.severe("Class not Found");
                System.exit(40);
            }
            catch (Exception e)
            {
                System.out.println(e);
                LOGGER.severe("Failed to create instance of Financial Report.");
                LOGGER.severe("Given FQN: " + fullyQualifiedName);
                System.exit(50);
            }
        }
        else
        {
            System.out.println("Config Fail");
            System.exit(10);
        }
        return record;
    }

    public static boolean checkConfig(String fqn, Object base)
    {
       boolean a = true;
       if (fqn.equals("aisco.financialreport.incomewithfrequency.FinancialReportControllerImpl"))
        {
           String baseku = base.getClass().getCanonicalName();
           a = baseku.equals("aisco.financialreport.income.FinancialReportControllerImpl");
        }
        else if (fqn.equals("aisco.financialreport.expensewithfrequency.FinancialReportControllerImpl"))
        {
           String baseku = base.getClass().getCanonicalName();
           a = baseku.equals("aisco.financialreport.expense.FinancialReportControllerImpl");
        }
        return a;
    }
}
