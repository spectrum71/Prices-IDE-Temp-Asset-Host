package aisco.financialreport.core;

import java.util.*;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import aisco.financialreport.FinancialReportFactory;

import aisco.program.core.Program;
import aisco.chartofaccount.core.ChartOfAccount;

import prices.auth.vmj.annotations.Restricted;

public class FinancialReportControllerImpl extends FinancialReportControllerComponent {

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/financialreport/save")
    public List<HashMap<String,Object>> saveFinancialReport(VMJExchange vmjExchange) {
        FinancialReport financialReport = createFinancialReport(vmjExchange);
        financialReportDao.saveFinancialReport(financialReport);
        System.out.println(financialReport);
        return getAllFinancialReport(vmjExchange);
    }

    public FinancialReport createFinancialReport(VMJExchange vmjExchange) {
        String datestamp = vmjExchange.getGETParam("datestamp");
        String amountStr = vmjExchange.getGETParam("amount");
        long amount = Long.parseLong(amountStr);
        String description = vmjExchange.getGETParam("description");
        // Program program = null;
        // String idProgramStr = vmjExchange.getGETParam("idProgram");
        // if (idProgramStr != null) {
        //     // UUID idProgram = UUID.fromString(idProgramStr);
        //     int idProgram = Integer.parseInt(idProgramStr);
        //     program = financialReportDao.getProxyObject(aisco.program.core.ProgramComponent.class, idProgram);
        // }
        // ChartOfAccount coa = null;
        // String idCoaStr = vmjExchange.getGETParam("idCoa");
        // if (idCoaStr != null) {
        //     // UUID idCoaUUID = UUID.fromString(idCoaStr);
        //     int idCoaUUID = Integer.parseInt(idCoaStr);
        //     coa = financialReportDao.getProxyObject(aisco.chartofaccount.core.ChartOfAccountComponent.class, idCoaUUID);
        // }
        // FinancialReport financialReport = FinancialReportFactory.createFinancialReport("aisco.financialreport.core.FinancialReportImpl", datestamp, amount, description, program, coa);
        String programName = vmjExchange.getGETParam("programName");
        String idCoa = vmjExchange.getGETParam("idCoa");
        FinancialReport financialReport = FinancialReportFactory.createFinancialReport("aisco.financialreport.core.FinancialReportImpl", datestamp, amount, description, programName, idCoa);
        return financialReport;
    }

    // need to copy paste code from above because java doesn't have optional parameter
    // public FinancialReport createFinancialReport(VMJExchange vmjExchange, UUID id) {
    public FinancialReport createFinancialReport(VMJExchange vmjExchange, int id) {
        String datestamp = vmjExchange.getGETParam("datestamp");
        String amountStr = vmjExchange.getGETParam("amount");
        long amount = Long.parseLong(amountStr);
        String description = vmjExchange.getGETParam("description");
        // Program program = null;
        // String idProgramStr = vmjExchange.getGETParam("idProgram");
        // if (idProgramStr != null) {
        //     // UUID idProgram = UUID.fromString(idProgramStr);
        //     int idProgram = Integer.parseInt(idProgramStr);
        //     program = financialReportDao.getProxyObject(aisco.program.core.ProgramComponent.class, idProgram);
        // }
        // ChartOfAccount coa = null;
        // String idCoaStr = vmjExchange.getGETParam("idCoa");
        // if (idCoaStr != null) {
        //     // UUID idCoaUUID = UUID.fromString(idCoaStr);
        //     int idCoaUUID = Integer.parseInt(idCoaStr);
        //     coa = financialReportDao.getProxyObject(aisco.chartofaccount.core.ChartOfAccountComponent.class, idCoaUUID);
        // }
        // FinancialReport financialReport = FinancialReportFactory.createFinancialReport("aisco.financialreport.core.FinancialReportImpl", datestamp, amount, description, program, coa);
        String programName = vmjExchange.getGETParam("programName");
        String idCoa = vmjExchange.getGETParam("idCoa");
        FinancialReport financialReport = FinancialReportFactory.createFinancialReport("aisco.financialreport.core.FinancialReportImpl", datestamp, amount, description, programName, idCoa);
        return financialReport;
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/financialreport/update")
    public HashMap<String, Object> updateFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        FinancialReport financialReport = createFinancialReport(vmjExchange, id);
        financialReportDao.updateFinancialReport(financialReport);
        return financialReport.toHashMap();
    }

    @Route(url="call/financialreport/detail")
    public HashMap<String, Object> getFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        FinancialReport financialReport = financialReportDao.getFinancialReport(id);
        System.out.println(financialReport);
        return financialReport.toHashMap();
    }

    @Route(url="call/financialreport/list")
    public List<HashMap<String,Object>> getAllFinancialReport(VMJExchange vmjExchange) {
        List<FinancialReport> financialReportList = financialReportDao.getAllFinancialReport("FinancialReportImpl");
        return transformFinancialReportListToHashMap(financialReportList);
    }

    // TODO: bisa dimasukin ke kelas util
    public List<HashMap<String,Object>> transformFinancialReportListToHashMap(List<FinancialReport> financialReportList) {
        List<HashMap<String,Object>> resultList = new ArrayList<HashMap<String,Object>>();
        for(int i = 0; i < financialReportList.size(); i++) {
            resultList.add(financialReportList.get(i).toHashMap());
        }

        return resultList;
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/financialreport/delete")
    public List<HashMap<String,Object>> deleteFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        financialReportDao.deleteFinancialReport(id);
        return getAllFinancialReport(vmjExchange);
    }
}
