package aisco.financialreport.core;

import java.util.UUID;
import java.util.List;

import vmj.hibernate.integrator.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class FinancialReportDaoImpl extends FinancialReportDaoComponent {

    public FinancialReportDaoImpl(){ }

    public void saveFinancialReport(FinancialReport financialReport) {
        Transaction transaction = null;

        try (Session session = (HibernateUtil.getSessionFactory()).openSession()) {
            transaction = session.beginTransaction();
            session.save(financialReport);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    public void updateFinancialReport(FinancialReport financialReport) {
        Transaction transaction = null;

        try (Session session = (HibernateUtil.getSessionFactory()).openSession()) {
            transaction = session.beginTransaction();
            session.update(financialReport);
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            if (transaction != null) {
                transaction.rollback();
            }
        }
    }

    // public FinancialReport getFinancialReport(UUID id) {
    public FinancialReport getFinancialReport(int id) {
        Transaction transaction = null;
        FinancialReport financialReport = null;

        try (Session session = (HibernateUtil.getSessionFactory()).openSession()) {
            transaction = session.beginTransaction();
            financialReport = session.get(aisco.financialreport.core.FinancialReportComponent.class, id);
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            if (transaction != null) {
                transaction.rollback();
            }
        }

        return financialReport;
    }

    public List<FinancialReport> getAllFinancialReport(String tableName){
        Transaction transaction = null;
        List<FinancialReport> financialReportList = null;

        try (Session session = (HibernateUtil.getSessionFactory()).openSession()) {
            transaction = session.beginTransaction();
            String queryStr = "FROM " + tableName;
            financialReportList = session.createQuery(queryStr).getResultList();
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            if (transaction != null) {
                transaction.rollback();
            }
        }

        return financialReportList;
    }

    // public void deleteFinancialReport(UUID id) {
    public void deleteFinancialReport(int id) {
        Transaction transaction = null;
        FinancialReport financialReport = null;

        try (Session session = (HibernateUtil.getSessionFactory()).openSession()) {
            transaction = session.beginTransaction();
            financialReport = session.get(aisco.financialreport.core.FinancialReportComponent.class, id);
            if (financialReport != null) {
                session.delete(financialReport);
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            if (transaction != null) {
                transaction.rollback();
            }
        }
    }

    // public <T> T getProxyObject(Class<T> type, UUID idObject) {    
    public <T> T getProxyObject(Class<T> type, int idObject) {
        Transaction transaction = null;
        T program = null;

            try (Session session = (HibernateUtil.getSessionFactory()).openSession()) {
                transaction = session.beginTransaction();
                program = session.load(type, idObject);
                transaction.commit();
            } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            if (transaction != null) {
                transaction.rollback();
            }
        }

        return program;
    }
}
