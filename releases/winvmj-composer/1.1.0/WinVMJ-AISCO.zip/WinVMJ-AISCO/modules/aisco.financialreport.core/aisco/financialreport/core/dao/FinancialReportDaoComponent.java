package aisco.financialreport.core;

import java.util.UUID;
import java.util.List;

public abstract class FinancialReportDaoComponent implements FinancialReportDao {

    public abstract void saveFinancialReport(FinancialReport financialReport);
    public abstract void updateFinancialReport(FinancialReport financialReport);
    // public abstract FinancialReport getFinancialReport(UUID id);
    public abstract FinancialReport getFinancialReport(int id);
    public abstract List<FinancialReport> getAllFinancialReport(String tableName);
    // public abstract void deleteFinancialReport(UUID id);
    public abstract void deleteFinancialReport(int id);
    // public abstract <T> T getProxyObject(Class<T> type, UUID idObject);
    public abstract <T> T getProxyObject(Class<T> type, int idObject);
}
