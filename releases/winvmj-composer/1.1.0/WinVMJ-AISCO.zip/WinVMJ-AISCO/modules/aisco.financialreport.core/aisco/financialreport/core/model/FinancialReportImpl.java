package aisco.financialreport.core;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;

import aisco.program.core.Program;
import aisco.chartofaccount.core.ChartOfAccount;

@Entity
@Table(name="financialreport_impl")
public class FinancialReportImpl extends FinancialReportComponent {

    @Column
    protected String datestamp;

    @Column
    protected long amount;

    @Column
    protected String description;

    // protected Program program;

    // protected ChartOfAccount coa;

    // To adjust with imfl, temp fix, shoud've use the Program
    @Column
    protected String programName;

    // To adjust with imfl, temp fix, shoud've use the coa
    @Column
    protected String idCoa;

     // public FinancialReportImpl(String datestamp, long amount, String description, Program program, ChartOfAccount coa) {
    public FinancialReportImpl(String datestamp, long amount, String description, String programName,  String idCoa) {
        // this.id = UUID.randomUUID();
        Random r = new Random();
		this.id = r.nextInt();
        this.datestamp = datestamp;
        this.amount = amount;
        this.description = description;
        // this.program = program;
        // this.coa = coa;
        this.programName = programName;
        this.idCoa = idCoa;

    }

    // public FinancialReportImpl(UUID id, String datestamp, long amount, String description, Program program, ChartOfAccount coa) {
    // public FinancialReportImpl(int id, String datestamp, long amount, String description, Program program, ChartOfAccount coa) {
    public FinancialReportImpl(int id, String datestamp, long amount, String description, String programName,  String idCoa) {
        this.id = id;
        this.datestamp = datestamp;
        this.amount = amount;
        this.description = description;
        // this.program = program;
        // this.coa = coa;
        this.programName = programName;
        this.idCoa = idCoa;
    }

    public FinancialReportImpl() {
        // this.id = UUID.randomUUID();
        Random r = new Random();
		this.id = r.nextInt();
        this.datestamp = "";
        this.amount = 0;
        this.description = "";
    }

    // public UUID getId() {
    public int getId() {
        return this.id;
    }
    // public void setId(UUID id) {
    public void setId(int id) {
        this.id = id;
    }

    public String getDatestamp() {
        return this.datestamp;
    }
    public void setDatestamp(String datestamp) {
        this.datestamp = datestamp;
    }

    public long getAmount() {
        return this.amount;
    }
    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return this.description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    // public Program getProgram() {
    //     return this.program;
    // }
    // public void setProgram(Program program) {
    //     this.program = program;
    // }

    // public ChartOfAccount getCoa() {
    //     return this.coa;
    // }
    // public void setCoa(ChartOfAccount coa) {
    //     this.coa = coa;
    // }

    public String getProgramName() {
        return this.programName;
    }
    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getIdCoa() {
        return this.idCoa;
    }
    public void setIdCoa(String idCoa) {
        this.idCoa = idCoa;
    }

    @Route(url="printHeader")
    public HashMap<String, Object> printHeader(VMJExchange vmjExchange) {
        HashMap<String, Object> hasil = new HashMap<>();
        hasil.put("header", "Financial Report Core");
        return hasil;
    }

}
