module aisco.financialreport.chartless {
    exports aisco.financialreport.chartless;
    requires aisco.financialreport.core;
    requires vmj.object.mapper;
    requires vmj.routing.route;
    requires prices.auth.vmj;

    opens aisco.financialreport.chartless to org.hibernate.orm.core;
}
