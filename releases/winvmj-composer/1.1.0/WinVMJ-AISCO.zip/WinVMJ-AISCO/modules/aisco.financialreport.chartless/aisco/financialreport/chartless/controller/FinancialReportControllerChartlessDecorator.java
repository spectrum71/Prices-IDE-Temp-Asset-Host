package aisco.financialreport.chartless;
import java.util.*;

import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import aisco.financialreport.core.FinancialReportControllerDecorator;
import aisco.financialreport.core.FinancialReportControllerComponent;
import aisco.financialreport.core.FinancialReport;
import aisco.financialreport.core.FinancialReportDecorator;
import aisco.financialreport.FinancialReportFactory;

import prices.auth.vmj.annotations.Restricted;

public class FinancialReportControllerChartlessDecorator extends FinancialReportControllerDecorator {

    public FinancialReportControllerChartlessDecorator(FinancialReportControllerComponent record) {
        super(record);
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/chartless/save")
    public List<HashMap<String,Object>> saveFinancialReport(VMJExchange vmjExchange) {
        FinancialReport financialReport = createFinancialReport(vmjExchange);
        financialReportDao.saveFinancialReport(financialReport);
        System.out.println(financialReport);
        return getAllFinancialReport(vmjExchange);
    }

    public FinancialReport createFinancialReport(VMJExchange vmjExchange) {
        String datestamp = vmjExchange.getGETParam("datestamp");
        String amountStr = vmjExchange.getGETParam("amount");
        long amount = Long.parseLong(amountStr);
        String description = vmjExchange.getGETParam("description");
        String programName = vmjExchange.getGETParam("programName");
        FinancialReport financialReport = FinancialReportFactory.createFinancialReport("aisco.financialreport.chartless.FinancialReportChartlessDecorator", datestamp, amount, description, programName);
        return financialReport;
    }

    // need to copy paste code from above because java doesn't have optional parameter
    // public FinancialReport createFinancialReport(VMJExchange vmjExchange, UUID id) {
    public FinancialReport createFinancialReport(VMJExchange vmjExchange, int id) {
        String datestamp = vmjExchange.getGETParam("datestamp");
        String amountStr = vmjExchange.getGETParam("amount");
        long amount = Long.parseLong(amountStr);
        String description = vmjExchange.getGETParam("description");
        String programName = vmjExchange.getGETParam("programName");
        FinancialReport financialReport = FinancialReportFactory.createFinancialReport("aisco.financialreport.core.FinancialReportImpl", id, datestamp, amount, description, null, programName);
        return financialReport;
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/chartless/update")
    public HashMap<String, Object> updateFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        FinancialReport financialReport = createFinancialReport(vmjExchange, id);
        financialReportDao.updateFinancialReport(financialReport);
        System.out.println(financialReport);
        return financialReport.toHashMap();
    }

    @Route(url="call/chartless/detail")
    public HashMap<String, Object> getFinancialReport(VMJExchange vmjExchange) {
        return super.getFinancialReport(vmjExchange);
    }

    @Route(url="call/chartless/list")
    public List<HashMap<String,Object>> getAllFinancialReport(VMJExchange vmjExchange) {
        List<FinancialReport> financialReportList = financialReportDao.getAllFinancialReport("FinancialReportChartlessDecorator");
        return transformFinancialReportListToHashMap(financialReportList);
    }

    @Restricted(permissionName="ModifyFinancialReportImpl")
    @Route(url="call/chartless/delete")
    public List<HashMap<String,Object>> deleteFinancialReport(VMJExchange vmjExchange) {
        String idStr = vmjExchange.getGETParam("id");
        // UUID id = UUID.fromString(idStr);
        int id = Integer.parseInt(idStr);
        financialReportDao.deleteFinancialReport(id);
        return getAllFinancialReport(vmjExchange);
    }
}
