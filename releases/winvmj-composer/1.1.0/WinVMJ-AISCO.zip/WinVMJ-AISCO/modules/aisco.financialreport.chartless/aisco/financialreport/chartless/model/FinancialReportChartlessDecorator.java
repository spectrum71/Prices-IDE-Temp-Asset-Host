package aisco.financialreport.chartless;

import java.util.*;
import vmj.routing.route.Route;
import vmj.routing.route.VMJExchange;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;

import aisco.financialreport.core.FinancialReportDecorator;
import aisco.financialreport.core.FinancialReportComponent;

import aisco.program.core.Program;

@Entity
@Table(name="financialreport_chartless")
public class FinancialReportChartlessDecorator extends FinancialReportDecorator {

    @Column
    protected String datestamp;

    @Column
    protected long amount;

    @Column
    protected String description;

    // protected Program program;

    // To adjust with imfl, temp fix, shoud've use the Program
    @Column
    protected String programName;

    // public FinancialReportChartlessDecorator(String datestamp, long amount, String description, Program program) {
    public FinancialReportChartlessDecorator(String datestamp, long amount, String description, String programName) {
        // this.id = UUID.randomUUID();
        Random r = new Random();
		this.id = r.nextInt();
        this.datestamp = datestamp;
        this.amount = amount;
        this.description = description;
        // this.program = program;
        this.programName = programName;
        this.record = null;
    }

    public FinancialReportChartlessDecorator(){
        // this.id = UUID.randomUUID();
        Random r = new Random();
		this.id = r.nextInt();
        this.datestamp = "";
        this.amount = 0;
        this.description = "";
        // this.program = null;
        this.programName = "";
        this.record = null;
    }

    public String getDatestamp() {
        return this.datestamp;
    }
    public void setDatestamp(String datestamp) {
        this.datestamp = datestamp;
    }

    public long getAmount() {
        return this.amount;
    }
    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return this.description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    // public Program getProgram() {
    //     return this.program;
    // }
    // public void setProgram(Program program) {
    //     this.program = program;
    // }

    public String getProgramName() {
        return this.programName;
    }
    public void setProgramName(String programName) {
        this.programName = programName;
    }


    public String getIdCoa() {
        throw new UnsupportedOperationException();
    }
    public void setIdCoa(String idCoa) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", datestamp='" + getDatestamp() + "'" +
            ", amount='" + getAmount() + "'" +
            ", description='" + getDescription() + "'" +
            // ", idProgram='" + getProgram().getIdProgram() + "'" +
            ", programName='" + getProgramName() + "'" +
            "}";
    }

    @Override
    public HashMap<String, Object> toHashMap() {
        HashMap<String, Object> financialReportMap = new HashMap<String,Object>();
        financialReportMap.put("id", getId());
        financialReportMap.put("datestamp", getDatestamp());
        financialReportMap.put("amount", getAmount());
        financialReportMap.put("description", getDescription());
        // financialReportMap.put("idProgram", getProgram().getIdProgram());
        financialReportMap.put("programName", getProgramName());
        return financialReportMap;
    }
}
