INSERT INTO auth_user (id,password,allowedPermissions,name,email) VALUES (1,'fd4f97ae96ed4c0268d0b275765c849ce511419d96d6290ed583b9516f8cab61dfeddf43a522167bc9fa1eaeebb72b88158a2e646d1006799eb65a0e5805341a','administrator','Ichlasul Affan','ichlaffterlalu@gmail.com');
INSERT INTO auth_user (id,password,allowedPermissions,name,email) VALUES (2,'fd4f97ae96ed4c0268d0b275765c849ce511419d96d6290ed583b9516f8cab61dfeddf43a522167bc9fa1eaeebb72b88158a2e646d1006799eb65a0e5805341a','UpdateUserImpl,UpdateRoleImpl,UpdatePermissions','Ichlasul Affan (UI)','ichlasul.affan@ui.ac.id');
INSERT INTO auth_user (id,password,allowedPermissions,name,email) VALUES (3,'fd4f97ae96ed4c0268d0b275765c849ce511419d96d6290ed583b9516f8cab61dfeddf43a522167bc9fa1eaeebb72b88158a2e646d1006799eb65a0e5805341a','','Ichlasul Affan (Dummy)','ichlasul.affan@gmail.com');
INSERT INTO auth_user (id,password,allowedPermissions,name,email) VALUES (4,'fd4f97ae96ed4c0268d0b275765c849ce511419d96d6290ed583b9516f8cab61dfeddf43a522167bc9fa1eaeebb72b88158a2e646d1006799eb65a0e5805341a','','Falah Prasetyo Waluyo','falah.prasetyo01@ui.ac.id');
INSERT INTO auth_user (id,password,allowedPermissions,name,email) VALUES (5,'fd4f97ae96ed4c0268d0b275765c849ce511419d96d6290ed583b9516f8cab61dfeddf43a522167bc9fa1eaeebb72b88158a2e646d1006799eb65a0e5805341a','','Samuel Tupa Febrian','samuel.febrian@gmail.com');

INSERT INTO auth_role (id,name,allowedPermissions) VALUES (1,'register','');
INSERT INTO auth_role (id,name,allowedPermissions) VALUES (2,'administrator','administrator');
INSERT INTO auth_role (id,name,allowedPermissions) VALUES (3,'staff','ModifyFinancialReportImpl,ModifyProgramImpl,ModifyDonationImpl');
INSERT INTO auth_role (id,name,allowedPermissions) VALUES (4,'donator','ModifyDonationImpl');

INSERT INTO auth_user_role (id,role,user) VALUES (1,1,1);
INSERT INTO auth_user_role (id,role,user) VALUES (2,1,2);
INSERT INTO auth_user_role (id,role,user) VALUES (3,1,3);
INSERT INTO auth_user_role (id,role,user) VALUES (4,1,4);
INSERT INTO auth_user_role (id,role,user) VALUES (5,2,1);
INSERT INTO auth_user_role (id,role,user) VALUES (6,3,2);
INSERT INTO auth_user_role (id,role,user) VALUES (7,3,4);
INSERT INTO auth_user_role (id,role,user) VALUES (8,4,3);
INSERT INTO auth_user_role (id,role,user) VALUES (9,1,5);
INSERT INTO auth_user_role (id,role,user) VALUES (10,2,5);
INSERT INTO auth_user_role (id,role,user) VALUES (11,3,5);
INSERT INTO auth_user_role (id,role,user) VALUES (12,4,5);