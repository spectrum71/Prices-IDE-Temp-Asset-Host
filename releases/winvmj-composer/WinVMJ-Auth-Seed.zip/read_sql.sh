dbname=$1
sqlfile=$2
echo ".read $sqlfile" | sqlite3 $dbname
read -n 1 -s -r -p "Press any key to continue"